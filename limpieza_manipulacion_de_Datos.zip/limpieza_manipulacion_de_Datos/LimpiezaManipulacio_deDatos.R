library(readxl)
employmentEuro <- read_excel("C:/Users/Aponte/OneDrive/Documents/R/limpieza_manipulacion_de_Datos/data_social.xlsx", 
                                sheet = "Sheet 1", skip = 15)
view(employmentEuro)

#vector de los numero impares 3 a 21
x<-1+2*(1:10)

#removiendocolumnns 3,5,..,21
employmentEuro<-employmentEuro[,-c(x)]

#secuencia de los a~o 2005-2018
year = 2005:2014

#renombrando columnas 2 en adelante
names(employmentEuro)<-c("Country",year)

#eliminar filas
employmentEuro<-employmentEuro[-c(36:42),]


#cambiar valor a un elemento de la columna Country
employmentEuro$Country[employmentEuro$Country=="Germany (until 1990 former territory of the FRG)"]<-'Germany'

#los que tenga : se  lo cambia a NA
employmentEuro[employmentEuro==":"]<-NA

#solo valor decimal
employmentEuro[,-1]<- round(sapply(employmentEuro[,-1],as.numeric),1)


summary(employmentEuro)
