library(readxl)

node_tibble<-read_xlsx("data_social.xlsx",sheet="nodes")

edges_tibble<-read_xlsx("data_social.xlsx",sheet="edges")


