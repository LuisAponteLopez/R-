df<-c(18,14,8,14,9,13,12,10,11,10,13,10,13,13,14)

#Estadictica descriptiva simple
summary(df)#resumen estadistico
min(df)#minimo
max(df)#maximo
range(df)#rango
mean(df)#media
median(df)#mediana
length(df)#tamano
sd(df)#desviacion estandar
var(df)#varianza
##cor(df)#correlacion
quantile(df,0.25)#cuartil 1
quantile(df,0.5)#cuartil 2
quantile(df,0.75)#cuartil 3
IQR(df)# rango intercuartilico

#comando para el analisis grafico datos
stem(df) #diagrama de tallos y hoja
hist(df) #histrograma
boxplot(df)#grafico de boxplot
plot(df)#grafico de punto
pairs(df)#grafico de dispesion cruzado

#estilo a boxplot
par(mfrow=c(1,1))
boxplot(df,col="darkseagreen1",
        xlab="Variable A",
        ylab="Peso de frutos",
        main='Rendimiento de Fruntos de la variable A',
        points(mean(df),pch=8))


#Grafico con Ggplot2
install.packages(ggplot2)
install.packages(dplyr)
#cargar paquete
library(ggplot2)
library(dplyr)

#le doy copi a la tabla que quiero y esto toma los datos
df1<-read.delim("clipboard")

#grafica de histograma 

#aes => que voy a graficar 
a<- ggplot(df1,aes(x=Peso))

a+ geom_area(stat="bin",color="black",fill="#00AFBB")
a+geom_histogram()
a+geom_histogram(bins=100)+theme_bw() #theme_bw() es para eliminar el fondo gris

#separe por varieble en una misma barra
a+geom_histogram(aes(color=Variable),fill="white",bins=50)+theme_minimal()

a+geom_histogram(aes(color=Variable,fill=Variable),alpha=0.4,position ="identity",bins=50)+
                            scale_fill_manual(values=c("#00AFBB","#E78808"))+
                            scale_color_manual(values=c("#00AFBB","#E78808"))

#grafico de densidad
a+geom_density()

#densidades por variable
a + geom_density(aes(fill=Variable),alpha=.4)

#grafico histograma y densidad
a+geom_histogram(aes(y=..density..),color="black",fill="white")+
                  geom_density(alpha=.2, fill='#FF6666')
#vamos a separar por 2 densidades
a+geom_histogram(aes(y=..density..,color=Variable,fill=Variable),alpha=.4,position='identity')+
  geom_density(aes(color=Variable),size=1)


#grafico final
